package com.google.android.libraries.gsa.launcherclient;

public interface ISerializableScrollCallback extends IScrollCallback {
    void setPersistentFlags(int flags);
}
