package com.google.android.libraries.gsa.launcherclient;

public class StaticInteger {
    public final int mData;

    public StaticInteger(int data) {
        mData = data;
    }
}
