package com.google.android.apps.nexuslauncher.qsb;

public interface QsbChangeListener {
    void onChange();
}
