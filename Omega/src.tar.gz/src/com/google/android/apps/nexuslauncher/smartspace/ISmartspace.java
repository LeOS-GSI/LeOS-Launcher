package com.google.android.apps.nexuslauncher.smartspace;

public interface ISmartspace {
    void onGsaChanged();

    void cr(final SmartspaceDataContainer p0);
}
